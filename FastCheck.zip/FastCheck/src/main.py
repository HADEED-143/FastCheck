from urllib import response
import days
import owner as owner
from fastapi import FastAPI
from typing import Optional
from pydantic import BaseModel
from datetime import datetime, date
#from tortoise.contrib import pydantic
from src.models import additionalapis

app = FastAPI()


#insertcrete
@app.get("apicalls/")
def add_apicall(apiid, days=None, total_apis=None):

    limitdays = 90 * days
    #apicalls = apicalls.dict(exclude_unset=True)
    if apiid["total_apis"] > 0:
        total_tries = total_apis - apiid
        apiid["total_tries"] = ((apiid["total_apis"])) - apiid
        # --- =10000 - apiid
        for total_tries in limitdays:
            return apicalls

    else:
        days["total_tries"] < total_apis
        return {"you r adding additonal apis full"}

    for additionaltries in additionalapis:
        additionaltries = +1
        tries_left = additionaltries - 1
        return additionalapis


#view
@app.get("/apicalls")
async def get_apicalls(api_calls=None):
    #response = await apicalls_pydantic.from_tortoise_orm(api_calls.all())
    return {"Status": "ok", "data": response}

#retrieveall
@app.get("/apicalls{id}")
async def get_apicalls(id:int, apiid=None):
    apiid = await apiid.get(id=id)
    tries_left = await tries_left.tries_left

    #response = await apicalls_pydantic.from_queryset_single(apicalls.get(id=id))

    return {
        "status": "ok"
        # all json
    }

#delete
@app.delete("apicalls/{id}")
async def delete_apicalls(id:int, apicall_pydantic=None, apiid=None):
    apiid = await apiid.get(id = id)
    total_apis = await total_tries.total_tries

    if user == owner:
     apiid.delete()

    else:
        return()
#update
@app.put("/apicalls{id}")
async def update_apicalls():

#apiid = await apiid.get(id=id)
#additional_tries = await  additional_tries.get(id=id)
#update_api =update_api.dict(exclude_unset=True)

update_api["date Published"] = datetime.utcnow()
if user == owner and update_api[tries_left][add_apicall]:



#await apicalls_pydantic.update_from_dict(update_api
#register_tortoise(
   # app,
    #db_url="sqlite://database.sqlite3",
    #modules={"models": ["models"]},
    #generate_schemas=True,
    #add_exception_handlers=True
#)

