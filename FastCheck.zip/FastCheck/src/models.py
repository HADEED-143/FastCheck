import days
from tortoise import Model, fields
from pydantic import BaseModel
from datetime import datetime
from tortoise.contrib.pydantic import pydantic_model_creator


class role(BaseModel):
    user = "user"
    owner = "owner"

class apicalls(Model):
    apiid = fields.IntField(pk=True, index=True)
    license_start_date = fields.DatetimeField(datetime=days, days=90)
    version = fields.IntField(max_lenght=25)
    total_apis = fields.IntField(max_lenght=10000)
    validity = fields.BooleanField(default=True)
    total_tries = fields.IntField()
    role = fields.ForeignKeyField(role)
    is_verified = fields.BooleanField(default=False)
    joindata = fields.DatetimeField(default=datetime.utcnow())
    license_end_date = fields.DatetimeField(default=days)

class additionalapis(Model):
    apiid = fields.IntField(pk=True, index=True)
    datetime = fields.DatetimeField(default=datetime)
    additionaltries = fields.IntField(max_lenght=500)
    tries_left = fields.ForeignKeyField(model_name=apicalls, related_name="validity")

#apicalls_pydantic = pydantic_model_creator(apicalls, name="apicalls", exclude={"is_verified"})
#apicalls_pydanticIn = pydantic_model_creator(apicalls, name="apicallsIn", exclude_readonly=True)
#apicalls_pydanticOut = pydantic_model_creator(apicalls, name="apicallsout", exclude="Validity")

